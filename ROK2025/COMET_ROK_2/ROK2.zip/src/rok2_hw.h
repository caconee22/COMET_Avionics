#pragma once
// ============================================================
// ROK2 Hardware Header (header-only)
// Board: ESP32-C3 Super Mini (PlatformIO board: esp32-c3-devkitm-1)
// Peripherals: DS3231 (RTC), MPU6050 (IMU), BMP280 (Baro), RGB LED, Buzzer, Switch, Servo
// ============================================================

#include <Arduino.h>
#include <Wire.h>

#include <Adafruit_BMP280.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <RTClib.h>
#include <ESP32Servo.h>

// ============================================================
// User configuration (override via build_flags -D ...)
// ============================================================

// ---------------- Pin mapping ----------------
// Default: user mapping
#ifndef ROK2_PIN_SWITCH
#define ROK2_PIN_SWITCH 0   // D0 Switch (INPUT_PULLUP, pressed=LOW)
#endif

#ifndef ROK2_PIN_SERVO
#define ROK2_PIN_SERVO  1   // D1 PWM Servo
#endif

#ifndef ROK2_PIN_NC2
#define ROK2_PIN_NC2    2   // D2 NC
#endif

#ifndef ROK2_PIN_SIG
#define ROK2_PIN_SIG    3   // D3 SIG (optional)
#endif

#ifndef ROK2_PIN_LED_R
#define ROK2_PIN_LED_R  4   // D4 R
#endif

#ifndef ROK2_PIN_LED_G
#define ROK2_PIN_LED_G  5   // D5 G
#endif

#ifndef ROK2_PIN_LED_B
#define ROK2_PIN_LED_B  6   // D6 B
#endif

#ifndef ROK2_PIN_INT
#define ROK2_PIN_INT    7   // D7 MPU INT (optional)
#endif

#ifndef ROK2_PIN_SDA
#define ROK2_PIN_SDA    8   // D8 SDA
#endif

#ifndef ROK2_PIN_SCL
#define ROK2_PIN_SCL    9   // D9 SCL
#endif

#ifndef ROK2_PIN_BUZZER
#define ROK2_PIN_BUZZER 10  // D10 Buzzer (active, just power to sound)
#endif

#ifndef ROK2_PIN_RX
#define ROK2_PIN_RX     20  // D20 RX
#endif

#ifndef ROK2_PIN_TX
#define ROK2_PIN_TX     21  // D21 TX
#endif

// ---------------- I2C addresses ----------------
#ifndef ROK2_ADDR_DS3231
#define ROK2_ADDR_DS3231 0x68
#endif

#ifndef ROK2_ADDR_MPU6050
#define ROK2_ADDR_MPU6050 0x69
#endif

#ifndef ROK2_ADDR_BMP280
#define ROK2_ADDR_BMP280 0x77
#endif

// ---------------- I2C clock ----------------
#ifndef ROK2_I2C_CLOCK_HZ
#define ROK2_I2C_CLOCK_HZ 400000UL
#endif

// ---------------- RGB LED wiring ----------------
// 0: Common Cathode (HIGH=ON)
// 1: Common Anode (LOW=ON)
#ifndef ROK2_RGB_COMMON_ANODE
#define ROK2_RGB_COMMON_ANODE 0
#endif

// ---------------- Servo pulse range ----------------
#ifndef ROK2_SERVO_MIN_US
#define ROK2_SERVO_MIN_US 500
#endif

#ifndef ROK2_SERVO_MAX_US
#define ROK2_SERVO_MAX_US 2500
#endif

namespace rok2 {

// ============================================================
// Common constants (shared across project)
// ============================================================

// Baro altitude reference (hPa). Not for accurate absolute altitude, used for relative baseline / debug.
inline constexpr float SEA_LEVEL_HPA = 1013.25f;

// Angle conversion: radian -> degree
inline constexpr float ROK2_RAD2DEG = 57.29577951308232f; // 180/pi
inline float rad2deg(float r) { return r * ROK2_RAD2DEG; }

// ============================================================
// Pin constants
// ============================================================
static constexpr int PIN_SWITCH = ROK2_PIN_SWITCH;
static constexpr int PIN_SERVO  = ROK2_PIN_SERVO;
static constexpr int PIN_NC2    = ROK2_PIN_NC2;
static constexpr int PIN_SIG    = ROK2_PIN_SIG;

static constexpr int PIN_LED_R  = ROK2_PIN_LED_R;
static constexpr int PIN_LED_G  = ROK2_PIN_LED_G;
static constexpr int PIN_LED_B  = ROK2_PIN_LED_B;

static constexpr int PIN_INT    = ROK2_PIN_INT;
static constexpr int PIN_SDA    = ROK2_PIN_SDA;
static constexpr int PIN_SCL    = ROK2_PIN_SCL;

static constexpr int PIN_BUZZER = ROK2_PIN_BUZZER;
static constexpr int PIN_RX     = ROK2_PIN_RX;
static constexpr int PIN_TX     = ROK2_PIN_TX;

// ============================================================
// Address constants
// ============================================================
static constexpr uint8_t ADDR_RTC = (uint8_t)ROK2_ADDR_DS3231;
static constexpr uint8_t ADDR_MPU = (uint8_t)ROK2_ADDR_MPU6050;
static constexpr uint8_t ADDR_BMP = (uint8_t)ROK2_ADDR_BMP280;

static constexpr uint32_t I2C_CLOCK_HZ = (uint32_t)ROK2_I2C_CLOCK_HZ;

// ============================================================
// Device objects (header-only inline vars; requires C++17 recommended)
// ============================================================
inline RTC_DS3231 rtc;
inline Adafruit_MPU6050 mpu;
inline Adafruit_BMP280 bmp;
inline Servo servo;

// ============================================================
// Basic pin init
// ============================================================
inline void pinInitBasic() {
  // RGB
  pinMode(PIN_LED_R, OUTPUT);
  pinMode(PIN_LED_G, OUTPUT);
  pinMode(PIN_LED_B, OUTPUT);

  // default off
#if ROK2_RGB_COMMON_ANODE
  digitalWrite(PIN_LED_R, HIGH);
  digitalWrite(PIN_LED_G, HIGH);
  digitalWrite(PIN_LED_B, HIGH);
#else
  digitalWrite(PIN_LED_R, LOW);
  digitalWrite(PIN_LED_G, LOW);
  digitalWrite(PIN_LED_B, LOW);
#endif

  // buzzer
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);

  // switch / int
  pinMode(PIN_SWITCH, INPUT_PULLUP);
  pinMode(PIN_INT, INPUT_PULLUP);

  // optional pins
  pinMode(PIN_SIG, OUTPUT);
  digitalWrite(PIN_SIG, LOW);
}

// ============================================================
// I2C init / ping
// ============================================================
inline void wireBegin(uint32_t clk_hz = I2C_CLOCK_HZ) {
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(clk_hz);
}

inline bool i2cPing(uint8_t addr) {
  Wire.beginTransmission(addr);
  return (Wire.endTransmission() == 0);
}

// ============================================================
// RGB helpers
// ============================================================
inline void rgbWriteRaw(bool r_on, bool g_on, bool b_on) {
#if ROK2_RGB_COMMON_ANODE
  digitalWrite(PIN_LED_R, r_on ? LOW : HIGH);
  digitalWrite(PIN_LED_G, g_on ? LOW : HIGH);
  digitalWrite(PIN_LED_B, b_on ? LOW : HIGH);
#else
  digitalWrite(PIN_LED_R, r_on ? HIGH : LOW);
  digitalWrite(PIN_LED_G, g_on ? HIGH : LOW);
  digitalWrite(PIN_LED_B, b_on ? HIGH : LOW);
#endif
}

inline void rgbOff()     { rgbWriteRaw(false, false, false); }
inline void rgbRed()     { rgbWriteRaw(true,  false, false); }
inline void rgbGreen()   { rgbWriteRaw(false, true,  false); }
inline void rgbBlue()    { rgbWriteRaw(false, false, true ); }
inline void rgbYellow()  { rgbWriteRaw(true,  true,  false); }
inline void rgbCyan()    { rgbWriteRaw(false, true,  true ); }
inline void rgbMagenta() { rgbWriteRaw(true,  false, true ); }
inline void rgbWhite()   { rgbWriteRaw(true,  true,  true ); }

// ============================================================
// Buzzer helpers (active buzzer: HIGH=ON)
// ============================================================
inline void buzzerOn()  { digitalWrite(PIN_BUZZER, HIGH); }
inline void buzzerOff() { digitalWrite(PIN_BUZZER, LOW);  }

inline void buzzerBeepOnce(uint32_t ms_on = 120) {
  buzzerOn();
  delay(ms_on);
  buzzerOff();
}

// ============================================================
// Switch helper (INPUT_PULLUP; pressed=LOW)
// ============================================================
inline bool isSwitchPressed() {
  return (digitalRead(PIN_SWITCH) == LOW);
}

// ============================================================
// Device begin helpers
// ============================================================
inline bool beginRTC(bool &lostPower) {
  lostPower = false;
  if (!rtc.begin()) return false;
  lostPower = rtc.lostPower();
  return true;
}

// BMP280 begin: address fixed by macro
inline bool beginBMP280() {
  // Use I2C
  return bmp.begin(ADDR_BMP);
}

inline bool beginMPU6050() {
  if (!mpu.begin(ADDR_MPU)) return false;

  // sane defaults for rocket-ish telemetry
  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  return true;
}

// ============================================================
// Servo helper
// ============================================================
inline bool servoAttach(int minUs = ROK2_SERVO_MIN_US, int maxUs = ROK2_SERVO_MAX_US) {
  return servo.attach(PIN_SERVO, minUs, maxUs);
}

inline void servoWriteDeg(int deg) {
  // constrain for safety
  if (deg < 0) deg = 0;
  if (deg > 180) deg = 180;
  servo.write(deg);
}

} // namespace rok2
