#pragma once

#include "rok2_hw.h"
#include <math.h>

namespace rok2 {

// timing
static constexpr uint32_t SELFTEST_DURATION_MS = 2000;
static constexpr uint32_t SAMPLE_PERIOD_MS    = 50;

// BMP280 nonsense range
static constexpr float PRESSURE_MIN_PA = 30000.0f;
static constexpr float PRESSURE_MAX_PA = 120000.0f;
static constexpr float TEMP_MIN_C      = -40.0f;
static constexpr float TEMP_MAX_C      =  85.0f;

// MPU6050 nonsense range
static constexpr float ACC_ABS_MAX_MS2  = 120.0f;
static constexpr float GYRO_ABS_MAX_DPS = 1200.0f;

// fail blink
static constexpr uint32_t FAIL_BLINK_MS = 250;

// failure codes
enum class SelfTestFail : uint8_t {
  NONE = 0,
  I2C_MISSING_MPU,
  I2C_MISSING_BMP,
  BEGIN_MPU_FAIL,
  BEGIN_BMP_FAIL,
  BMP_NAN,
  BMP_PRESSURE_OOR,
  BMP_TEMP_OOR,
  MPU_NAN,
  MPU_ACCEL_OOR,
  MPU_GYRO_OOR,
};

inline void _failForever(SelfTestFail code,
                         float v1 = NAN, float v2 = NAN, float v3 = NAN) {
  Serial.println();
  Serial.println("=== SELFTEST FAIL ===");
  Serial.print("code: "); Serial.println((int)code);
  if (isfinite(v1) || isfinite(v2) || isfinite(v3)) {
    Serial.print("detail: ");
    if (isfinite(v1)) Serial.print(v1, 3); else Serial.print("NAN");
    Serial.print(", ");
    if (isfinite(v2)) Serial.print(v2, 3); else Serial.print("NAN");
    Serial.print(", ");
    if (isfinite(v3)) Serial.print(v3, 3); else Serial.print("NAN");
    Serial.println();
  }
  Serial.println("Action: system halted (red blinking).");
  Serial.println("=====================");
  Serial.println();

  uint32_t last = millis();
  bool on = false;

  while (true) {
    uint32_t now = millis();
    if (now - last >= FAIL_BLINK_MS) {
      last = now;
      on = !on;
      if (on) rgbRed();
      else    rgbOff();
    }
    delay(1);
  }
}

inline void runSelfTestOrHalt() {
  Serial.println();
  Serial.println("=== ROK2 SELFTEST (nonsense check only) ===");

  rgbRed();

  const bool hasRTC = i2cPing(ADDR_RTC);
  const bool hasMPU = i2cPing(ADDR_MPU);
  const bool hasBMP = i2cPing(ADDR_BMP);

  Serial.print("I2C ping RTC(0x68): "); Serial.println(hasRTC ? "OK" : "FAIL");
  Serial.print("I2C ping MPU(0x69): "); Serial.println(hasMPU ? "OK" : "FAIL");
  Serial.print("I2C ping BMP(0x77): "); Serial.println(hasBMP ? "OK" : "FAIL");

  if (!hasMPU) _failForever(SelfTestFail::I2C_MISSING_MPU);
  if (!hasBMP) _failForever(SelfTestFail::I2C_MISSING_BMP);

  bool rtcLost = false;
  bool rtcOK = beginRTC(rtcLost);
  Serial.print("RTC begin: "); Serial.println(rtcOK ? "OK" : "FAIL");
  if (rtcOK) {
    Serial.print("RTC lostPower: "); Serial.println(rtcLost ? "YES" : "NO");
  }

  if (!beginMPU6050()) _failForever(SelfTestFail::BEGIN_MPU_FAIL);
  Serial.println("MPU begin: OK");

  if (!beginBMP280()) _failForever(SelfTestFail::BEGIN_BMP_FAIL);
  Serial.println("BMP begin: OK");

  uint32_t samples = 0;

  float minP = +INFINITY, maxP = -INFINITY;
  float minT = +INFINITY, maxT = -INFINITY;
  float maxAbsAx = 0, maxAbsAy = 0, maxAbsAz = 0;
  float maxAbsGx = 0, maxAbsGy = 0, maxAbsGz = 0;

  Serial.println("[SELFTEST] sampling...");

  const uint32_t start = millis();
  uint32_t lastSample = start;

  while (millis() - start < SELFTEST_DURATION_MS) {
    const uint32_t now = millis();
    if (now - lastSample < SAMPLE_PERIOD_MS) {
      delay(1);
      continue;
    }
    lastSample = now;

    const float p = bmp.readPressure();
    const float t = bmp.readTemperature();
    (void)bmp.readAltitude(SEA_LEVEL_HPA);

    if (!isfinite(p) || !isfinite(t)) {
      _failForever(SelfTestFail::BMP_NAN, p, t, NAN);
    }
    minP = min(minP, p);
    maxP = max(maxP, p);
    minT = min(minT, t);
    maxT = max(maxT, t);

    if (p < PRESSURE_MIN_PA || p > PRESSURE_MAX_PA) {
      _failForever(SelfTestFail::BMP_PRESSURE_OOR, p, PRESSURE_MIN_PA, PRESSURE_MAX_PA);
    }
    if (t < TEMP_MIN_C || t > TEMP_MAX_C) {
      _failForever(SelfTestFail::BMP_TEMP_OOR, t, TEMP_MIN_C, TEMP_MAX_C);
    }

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    const float ax = a.acceleration.x;
    const float ay = a.acceleration.y;
    const float az = a.acceleration.z;

    const float gx = g.gyro.x * (180.0f / (float)M_PI);
    const float gy = g.gyro.y * (180.0f / (float)M_PI);
    const float gz = g.gyro.z * (180.0f / (float)M_PI);

    if (!isfinite(ax) || !isfinite(ay) || !isfinite(az) ||
        !isfinite(gx) || !isfinite(gy) || !isfinite(gz)) {
      _failForever(SelfTestFail::MPU_NAN, ax, ay, az);
    }

    maxAbsAx = max(maxAbsAx, fabsf(ax));
    maxAbsAy = max(maxAbsAy, fabsf(ay));
    maxAbsAz = max(maxAbsAz, fabsf(az));

    maxAbsGx = max(maxAbsGx, fabsf(gx));
    maxAbsGy = max(maxAbsGy, fabsf(gy));
    maxAbsGz = max(maxAbsGz, fabsf(gz));

    if (fabsf(ax) > ACC_ABS_MAX_MS2 ||
        fabsf(ay) > ACC_ABS_MAX_MS2 ||
        fabsf(az) > ACC_ABS_MAX_MS2) {
      _failForever(SelfTestFail::MPU_ACCEL_OOR, ax, ay, az);
    }

    if (fabsf(gx) > GYRO_ABS_MAX_DPS ||
        fabsf(gy) > GYRO_ABS_MAX_DPS ||
        fabsf(gz) > GYRO_ABS_MAX_DPS) {
      _failForever(SelfTestFail::MPU_GYRO_OOR, gx, gy, gz);
    }

    samples++;
  }

  Serial.println();
  Serial.println("=== SELFTEST SUMMARY ===");
  Serial.print("samples: "); Serial.println(samples);
  Serial.print("pressure range (Pa): "); Serial.print(minP, 2); Serial.print(" .. "); Serial.println(maxP, 2);
  Serial.print("baro temp range (C): "); Serial.print(minT, 2); Serial.print(" .. "); Serial.println(maxT, 2);

  Serial.print("max abs accel (m/s^2) ax,ay,az: ");
  Serial.print(maxAbsAx, 2); Serial.print(", ");
  Serial.print(maxAbsAy, 2); Serial.print(", ");
  Serial.println(maxAbsAz, 2);

  Serial.print("max abs gyro (dps) gx,gy,gz: ");
  Serial.print(maxAbsGx, 2); Serial.print(", ");
  Serial.print(maxAbsGy, 2); Serial.print(", ");
  Serial.println(maxAbsGz, 2);

  Serial.println("SELFTEST_RESULT: PASS");
  Serial.println("======================");
  Serial.println();

  rgbBlue();
  delay(1000);
  rgbOff();
}

} // namespace rok2
