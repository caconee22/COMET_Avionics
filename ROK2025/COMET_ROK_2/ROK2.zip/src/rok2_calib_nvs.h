#pragma once

#include "rok2_hw.h"
#include <Preferences.h>
#include <math.h>

namespace rok2 {

struct CalibData {
  uint32_t version = 1;

  float alt0_m = 0.0f;
  float pressure0_pa = 0.0f;
  float baro_temp0_c = 0.0f;

  float roll0_deg = 0.0f;
  float pitch0_deg = 0.0f;
  float yaw0_deg = 0.0f;

  float gyro_bias_x_dps = 0.0f;
  float gyro_bias_y_dps = 0.0f;
  float gyro_bias_z_dps = 0.0f;

  uint32_t saved_at_ms = 0;
};

inline CalibData calib;

// NVS keys
static constexpr const char* NVS_NS = "rok2";
static constexpr uint32_t CALIB_HOLD_MS = 3000;
static constexpr uint32_t BEEP_MS = 120;

// Baro stabilize
static constexpr uint32_t ALT_STABLE_TOTAL_MS = 2500;
static constexpr uint32_t ALT_SAMPLE_MS = 50;
static constexpr float ALT_STABLE_RANGE_M = 0.30f;

// ---------------- helpers ----------------
inline bool _buttonPressed() {
  return (digitalRead(PIN_SWITCH) == LOW);
}

inline void _buzzerBeepOnce(uint32_t ms = BEEP_MS) {
  buzzerOn();
  delay(ms);
  buzzerOff();
}

inline void _buzzerBeepTwice() {
  _buzzerBeepOnce(120);
  delay(80);
  _buzzerBeepOnce(120);
}

inline float _rad2deg(float r) { return r * (180.0f / (float)M_PI); }

inline void _estimateRollPitchFromAccel(float ax, float ay, float az,
                                        float &roll_deg, float &pitch_deg) {
  roll_deg  = _rad2deg(atan2f(ay, az));
  pitch_deg = _rad2deg(atan2f(-ax, sqrtf(ay*ay + az*az)));
}

// ---------------- NVS ----------------
inline bool loadCalibFromNVS(CalibData &out) {
  Preferences prefs;
  if (!prefs.begin(NVS_NS, true)) return false;

  uint32_t ver = prefs.getUInt("ver", 0);
  if (ver == 0) { prefs.end(); return false; }

  out.version = ver;
  out.alt0_m = prefs.getFloat("alt0", 0.0f);
  out.pressure0_pa = prefs.getFloat("p0", 0.0f);
  out.baro_temp0_c = prefs.getFloat("t0", 0.0f);

  out.roll0_deg = prefs.getFloat("r0", 0.0f);
  out.pitch0_deg = prefs.getFloat("pt0", 0.0f);
  out.yaw0_deg = prefs.getFloat("y0", 0.0f);

  out.gyro_bias_x_dps = prefs.getFloat("gbx", 0.0f);
  out.gyro_bias_y_dps = prefs.getFloat("gby", 0.0f);
  out.gyro_bias_z_dps = prefs.getFloat("gbz", 0.0f);

  out.saved_at_ms = prefs.getUInt("savems", 0);

  prefs.end();
  return true;
}

inline bool saveCalibToNVS(const CalibData &in) {
  Preferences prefs;
  if (!prefs.begin(NVS_NS, false)) return false;

  prefs.putUInt("ver", in.version);

  prefs.putFloat("alt0", in.alt0_m);
  prefs.putFloat("p0", in.pressure0_pa);
  prefs.putFloat("t0", in.baro_temp0_c);

  prefs.putFloat("r0", in.roll0_deg);
  prefs.putFloat("pt0", in.pitch0_deg);
  prefs.putFloat("y0", in.yaw0_deg);

  prefs.putFloat("gbx", in.gyro_bias_x_dps);
  prefs.putFloat("gby", in.gyro_bias_y_dps);
  prefs.putFloat("gbz", in.gyro_bias_z_dps);

  prefs.putUInt("savems", in.saved_at_ms);

  prefs.end();
  return true;
}

inline void printCalib(const CalibData &c, const char* title) {
  Serial.println();
  Serial.println(title);
  Serial.print("ver="); Serial.println(c.version);

  Serial.print("alt0_m="); Serial.println(c.alt0_m, 3);
  Serial.print("pressure0_pa="); Serial.println(c.pressure0_pa, 2);
  Serial.print("baro_temp0_c="); Serial.println(c.baro_temp0_c, 2);

  Serial.print("roll0_deg="); Serial.println(c.roll0_deg, 3);
  Serial.print("pitch0_deg="); Serial.println(c.pitch0_deg, 3);
  Serial.print("yaw0_deg="); Serial.println(c.yaw0_deg, 3);

  Serial.print("gyro_bias_dps(x,y,z)=");
  Serial.print(c.gyro_bias_x_dps, 3); Serial.print(", ");
  Serial.print(c.gyro_bias_y_dps, 3); Serial.print(", ");
  Serial.println(c.gyro_bias_z_dps, 3);

  Serial.print("saved_at_ms="); Serial.println(c.saved_at_ms);
  Serial.println();
}

// ---------------- CALIB ----------------
inline void runCalibrationAndSaveToNVS() {
  Serial.println();
  Serial.println("=== CALIB MODE (NVS save) ===");
  Serial.println("Hold still as much as possible for ~2-3 seconds.");

  rgbMagenta();

  // Baro window
  float alt_min = +INFINITY, alt_max = -INFINITY;
  float p_sum = 0.0f, t_sum = 0.0f, alt_sum = 0.0f;
  uint32_t n = 0;

  const uint32_t start = millis();
  uint32_t last = start;

  while (millis() - start < ALT_STABLE_TOTAL_MS) {
    uint32_t now = millis();
    if (now - last < ALT_SAMPLE_MS) { delay(1); continue; }
    last = now;

    float p = bmp.readPressure();
    float t = bmp.readTemperature();
    float alt = bmp.readAltitude(SEA_LEVEL_HPA);

    if (!isfinite(p) || !isfinite(t) || !isfinite(alt)) {
      Serial.println("[CALIB] BMP read invalid -> abort");
      rgbRed();
      _buzzerBeepTwice();
      while (true) { delay(10); }
    }

    alt_min = min(alt_min, alt);
    alt_max = max(alt_max, alt);

    p_sum += p;
    t_sum += t;
    alt_sum += alt;
    n++;
  }

  float alt_avg = (n ? alt_sum / (float)n : 0.0f);
  float p_avg   = (n ? p_sum   / (float)n : 0.0f);
  float t_avg   = (n ? t_sum   / (float)n : 0.0f);
  float alt_range = alt_max - alt_min;

  Serial.print("[CALIB] Baro samples="); Serial.println(n);
  Serial.print("[CALIB] Alt(avg,range) m = "); Serial.print(alt_avg, 3);
  Serial.print(", "); Serial.println(alt_range, 3);

  if (alt_range > ALT_STABLE_RANGE_M) {
    Serial.println("[CALIB] WARNING: altitude not stable (range too large). Saved anyway.");
  } else {
    Serial.println("[CALIB] Altitude considered stable.");
  }

  // IMU window (gyro bias + roll/pitch reference)
  double sum_gx = 0, sum_gy = 0, sum_gz = 0;
  double sum_ax = 0, sum_ay = 0, sum_az = 0;
  uint32_t m = 0;

  const uint32_t imu_start = millis();
  uint32_t imu_last = imu_start;

  while (millis() - imu_start < 2000) {
    uint32_t now = millis();
    if (now - imu_last < 20) { delay(1); continue; }
    imu_last = now;

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    float ax = a.acceleration.x;
    float ay = a.acceleration.y;
    float az = a.acceleration.z;

    float gx_dps = g.gyro.x * (180.0f / (float)M_PI);
    float gy_dps = g.gyro.y * (180.0f / (float)M_PI);
    float gz_dps = g.gyro.z * (180.0f / (float)M_PI);

    if (!isfinite(ax) || !isfinite(ay) || !isfinite(az) ||
        !isfinite(gx_dps) || !isfinite(gy_dps) || !isfinite(gz_dps)) {
      Serial.println("[CALIB] MPU read invalid -> abort");
      rgbRed();
      _buzzerBeepTwice();
      while (true) { delay(10); }
    }

    sum_ax += ax; sum_ay += ay; sum_az += az;
    sum_gx += gx_dps; sum_gy += gy_dps; sum_gz += gz_dps;
    m++;
  }

  float ax_avg = (m ? (float)(sum_ax / (double)m) : 0.0f);
  float ay_avg = (m ? (float)(sum_ay / (double)m) : 0.0f);
  float az_avg = (m ? (float)(sum_az / (double)m) : 0.0f);

  float gbx = (m ? (float)(sum_gx / (double)m) : 0.0f);
  float gby = (m ? (float)(sum_gy / (double)m) : 0.0f);
  float gbz = (m ? (float)(sum_gz / (double)m) : 0.0f);

  float roll0 = 0.0f, pitch0 = 0.0f;
  _estimateRollPitchFromAccel(ax_avg, ay_avg, az_avg, roll0, pitch0);

  CalibData c;
  c.version = 1;
  c.alt0_m = alt_avg;
  c.pressure0_pa = p_avg;
  c.baro_temp0_c = t_avg;

  c.roll0_deg = roll0;
  c.pitch0_deg = pitch0;
  c.yaw0_deg = 0.0f;

  c.gyro_bias_x_dps = gbx;
  c.gyro_bias_y_dps = gby;
  c.gyro_bias_z_dps = gbz;

  c.saved_at_ms = millis();

  printCalib(c, "=== CALIB TO SAVE ===");

  if (!saveCalibToNVS(c)) {
    Serial.println("[CALIB] NVS save FAILED");
    rgbRed();
    _buzzerBeepTwice();
    while (true) { delay(10); }
  }

  calib = c;
  Serial.println("[CALIB] NVS save OK. Applied.");
  _buzzerBeepTwice();
  rgbOff();
}

inline void handleCalibButtonOrLoadAfterSelftest() {
  if (_buttonPressed()) {
    Serial.println("[BOOT] Button pressed -> beep once. Hold 3s to enter CALIB.");
    _buzzerBeepOnce(120);

    uint32_t t0 = millis();
    while (_buttonPressed()) {
      if (millis() - t0 >= CALIB_HOLD_MS) {
        Serial.println("[BOOT] Button held >=3s -> enter CALIB.");
        _buzzerBeepTwice();
        runCalibrationAndSaveToNVS();
        return;
      }
      delay(5);
    }

    Serial.println("[BOOT] Button released before 3s -> normal boot.");
  }

  CalibData loaded;
  if (loadCalibFromNVS(loaded)) {
    calib = loaded;
    printCalib(calib, "=== CALIB LOADED (NVS) ===");
    Serial.println("[BOOT] Calib applied.");
  } else {
    Serial.println("[BOOT] No calib in NVS. Using defaults (zero).");
    calib = CalibData{};
    printCalib(calib, "=== CALIB DEFAULT ===");
  }
}

// 보정 적용 헬퍼
inline float applyAltCalib(float alt_raw_m) {
  return alt_raw_m - calib.alt0_m;
}

inline void applyGyroBias(float &gx_dps, float &gy_dps, float &gz_dps) {
  gx_dps -= calib.gyro_bias_x_dps;
  gy_dps -= calib.gyro_bias_y_dps;
  gz_dps -= calib.gyro_bias_z_dps;
}

inline void applyAngleZero(float &roll_deg, float &pitch_deg, float &yaw_deg) {
  roll_deg  -= calib.roll0_deg;
  pitch_deg -= calib.pitch0_deg;
  yaw_deg   -= calib.yaw0_deg;
}

} // namespace rok2
