#pragma once
// ============================================================
// rok2_telemetry.h (header-only)
// - Update sensors at 10Hz (non-blocking)
// - Print human-readable dashboard at 5Hz (default)
// - Optional CSV output
// ============================================================

#include "rok2_hw.h"
#include "rok2_calib_nvs.h"

#include <Arduino.h>
#include <math.h>

namespace rok2 {

// ============================================================
// Config
// ============================================================

// Sensor update rate
static constexpr uint32_t TELEMETRY_UPDATE_MS = 100; // 10Hz

// Human readable print rate (recommended 2~5Hz)
static constexpr uint32_t HUMAN_PRINT_MS = 200; // 5Hz

// If you want CSV at 10Hz, set this to 1 and call printTelemetryCSVLine()
#ifndef ROK2_TELEM_ENABLE_CSV
#define ROK2_TELEM_ENABLE_CSV 0
#endif

// ============================================================
// Frame (can later be reused for BIN record)
// ============================================================

struct TelemetryFrame {
  uint32_t t_ms = 0;

  // IMU raw
  float ax = 0, ay = 0, az = 0;     // m/s^2
  float gx_dps = 0, gy_dps = 0, gz_dps = 0; // deg/s (bias corrected)
  float imu_temp_c = 0;

  // Baro raw
  float pressure_pa = 0;
  float baro_temp_c = 0;
  float alt_raw_m = 0;  // bmp altitude using SEA_LEVEL_HPA
  float alt_rel_m = 0;  // alt_raw - calib.alt0

  // Angles (from accel only) + zeroed (deg)
  float roll_raw_deg = 0;
  float pitch_raw_deg = 0;
  float roll0_deg = 0;   // after zero offset
  float pitch0_deg = 0;  // after zero offset

  // Flags for FSM/event later
  uint32_t flags = 0;
};

inline TelemetryFrame telem;

// ============================================================
// Internal timers
// ============================================================
inline uint32_t _lastUpdateMs = 0;
inline uint32_t _lastHumanMs  = 0;

// ============================================================
// Math helpers
// ============================================================

inline float _vec3norm(float x, float y, float z) {
  return sqrtf(x*x + y*y + z*z);
}

inline void _rollPitchFromAccel(float ax, float ay, float az,
                                float &roll_deg, float &pitch_deg) {
  // roll  = atan2(ay, az)
  // pitch = atan2(-ax, sqrt(ay^2 + az^2))
  roll_deg  = rok2::rad2deg(atan2f(ay, az));
  pitch_deg = rok2::rad2deg(atan2f(-ax, sqrtf(ay*ay + az*az)));
}

// ============================================================
// CSV header/line (optional)
// ============================================================

inline void printTelemetryHeader() {
  Serial.println(
    "t_ms,"
    "ax,ay,az,"
    "gx_dps,gy_dps,gz_dps,"
    "roll_deg,pitch_deg,"
    "roll0_deg,pitch0_deg,"
    "pressure_pa,baro_temp_c,"
    "alt_raw_m,alt_rel_m,"
    "imu_temp_c,"
    "flags"
  );
}

inline void printTelemetryCSVLine() {
  Serial.print(telem.t_ms); Serial.print(",");

  Serial.print(telem.ax, 3); Serial.print(",");
  Serial.print(telem.ay, 3); Serial.print(",");
  Serial.print(telem.az, 3); Serial.print(",");

  Serial.print(telem.gx_dps, 3); Serial.print(",");
  Serial.print(telem.gy_dps, 3); Serial.print(",");
  Serial.print(telem.gz_dps, 3); Serial.print(",");

  Serial.print(telem.roll0_deg, 3); Serial.print(",");
  Serial.print(telem.pitch0_deg, 3); Serial.print(",");

  Serial.print(calib.roll0_deg, 3); Serial.print(",");
  Serial.print(calib.pitch0_deg, 3); Serial.print(",");

  Serial.print(telem.pressure_pa, 2); Serial.print(",");
  Serial.print(telem.baro_temp_c, 2); Serial.print(",");

  Serial.print(telem.alt_raw_m, 3); Serial.print(",");
  Serial.print(telem.alt_rel_m, 3); Serial.print(",");

  Serial.print(telem.imu_temp_c, 2); Serial.print(",");
  Serial.println(telem.flags);
}

// ============================================================
// Human readable dashboard
// ============================================================

inline void printTelemetryHuman() {
  const float a_norm = _vec3norm(telem.ax, telem.ay, telem.az);
  const float g_norm = _vec3norm(telem.gx_dps, telem.gy_dps, telem.gz_dps);

  // line 1
  Serial.print("t=");
  Serial.print(telem.t_ms / 1000.0f, 1);
  Serial.print("s | ALTrel=");
  Serial.print(telem.alt_rel_m, 2);
  Serial.print("m | P=");
  Serial.print(telem.pressure_pa, 2);
  Serial.print("Pa | T_baro=");
  Serial.print(telem.baro_temp_c, 2);
  Serial.print("C | IMU_T=");
  Serial.print(telem.imu_temp_c, 2);
  Serial.println("C");

  // line 2
  Serial.print("A[m/s2]=(");
  Serial.print(telem.ax, 2); Serial.print(",");
  Serial.print(telem.ay, 2); Serial.print(",");
  Serial.print(telem.az, 2); Serial.print(") | |A|=");
  Serial.print(a_norm, 2);

  Serial.print(" | G[dps]=(");
  Serial.print(telem.gx_dps, 2); Serial.print(",");
  Serial.print(telem.gy_dps, 2); Serial.print(",");
  Serial.print(telem.gz_dps, 2); Serial.print(") | |G|=");
  Serial.print(g_norm, 2);
  Serial.println();

  // line 3
  Serial.print("RP[deg]=(");
  Serial.print(telem.roll0_deg, 2); Serial.print(",");
  Serial.print(telem.pitch0_deg, 2);
  Serial.print(")  (zero r0=");
  Serial.print(calib.roll0_deg, 2);
  Serial.print(" p0=");
  Serial.print(calib.pitch0_deg, 2);
  Serial.print(") | flags=0x");
  Serial.println(telem.flags, HEX);

  Serial.println("------------------------------------------------------------");
}

// ============================================================
// Telemetry update (10Hz, non-blocking)
// ============================================================

/**
 * @brief Updates 'telem' at 10Hz. No printing. Non-blocking.
 * @return true if updated this call.
 */
inline bool updateTelemetry10Hz() {
  const uint32_t now = millis();
  if ((uint32_t)(now - _lastUpdateMs) < TELEMETRY_UPDATE_MS) return false;
  _lastUpdateMs = now;

  // ---------- MPU ----------
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  const float ax = a.acceleration.x;
  const float ay = a.acceleration.y;
  const float az = a.acceleration.z;

  float gx_dps = g.gyro.x * (180.0f / (float)M_PI);
  float gy_dps = g.gyro.y * (180.0f / (float)M_PI);
  float gz_dps = g.gyro.z * (180.0f / (float)M_PI);

  // apply gyro bias
  applyGyroBias(gx_dps, gy_dps, gz_dps);

  // accel-based roll/pitch + zero offsets
  float roll_raw, pitch_raw;
  _rollPitchFromAccel(ax, ay, az, roll_raw, pitch_raw);

  float roll0 = roll_raw;
  float pitch0 = pitch_raw;
  float yaw0 = 0.0f;
  applyAngleZero(roll0, pitch0, yaw0);

  // ---------- BMP ----------
  const float p_pa = bmp.readPressure();
  const float t_c  = bmp.readTemperature();
  const float alt_raw = bmp.readAltitude(SEA_LEVEL_HPA);
  const float alt_rel = applyAltCalib(alt_raw);

  // ---------- fill frame ----------
  telem.t_ms = now;

  telem.ax = ax; telem.ay = ay; telem.az = az;
  telem.gx_dps = gx_dps; telem.gy_dps = gy_dps; telem.gz_dps = gz_dps;
  telem.imu_temp_c = temp.temperature;

  telem.pressure_pa = p_pa;
  telem.baro_temp_c = t_c;
  telem.alt_raw_m = alt_raw;
  telem.alt_rel_m = alt_rel;

  telem.roll_raw_deg = roll_raw;
  telem.pitch_raw_deg = pitch_raw;
  telem.roll0_deg = roll0;
  telem.pitch0_deg = pitch0;

  // TODO: flags will be set by FSM/event module later
  telem.flags = 0;

  return true;
}

// ============================================================
// Combined convenience APIs
// ============================================================

/**
 * @brief Updates telemetry at 10Hz, prints human dashboard at 5Hz.
 * Call this in loop().
 */
inline void updateAndPrintHuman() {
  const bool updated = updateTelemetry10Hz();
  if (!updated) return;

  const uint32_t now = millis();
  if ((uint32_t)(now - _lastHumanMs) < HUMAN_PRINT_MS) return;
  _lastHumanMs = now;

  printTelemetryHuman();
}

/**
 * @brief Updates telemetry at 10Hz, prints CSV line whenever updated.
 * If you want CSV in loop(), call this instead.
 */
inline void updateAndPrintCSV10Hz() {
  if (!updateTelemetry10Hz()) return;
  printTelemetryCSVLine();
}

} // namespace rok2
