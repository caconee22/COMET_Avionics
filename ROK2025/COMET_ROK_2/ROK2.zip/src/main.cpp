#include "rok2_hw.h"
#include "rok2_selftest.h"
#include "rok2_calib_nvs.h"
#include "rok2_telemetry.h"

void setup() {
  Serial.begin(115200);

  rok2::pinInitBasic();
  rok2::wireBegin();

  delay(3000);
  rok2::runSelfTestOrHalt();

  rok2::handleCalibButtonOrLoadAfterSelftest();

  rok2::printTelemetryHeader();
}

void loop() {
  rok2::updateAndPrintHuman();
}
